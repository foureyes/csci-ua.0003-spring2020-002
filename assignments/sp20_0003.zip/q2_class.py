class Element:
    """TODO: finish the Element class. 
    """


if __name__ == '__main__':
    n = Element('a', {'className': 'foo', 'href': '/bar/baz'}, 'qux')
    print(n)
