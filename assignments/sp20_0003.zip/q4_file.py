def sort_abs():  # TODO: add this function's parameters
    """TODO: complete this function's body
    """


if __name__ == '__main__':
    print(sort_abs('data.txt', 4))

