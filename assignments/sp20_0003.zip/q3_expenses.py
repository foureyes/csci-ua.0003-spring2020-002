def add_expenses():  # TODO: add this function's parameter(s)
    """TODO: complete this function
    """


def format_output():  # TODO: add this function's parameter(s)
    """TODO: complete this function
    """


if __name__ == '__main__':
    expenses = add_expenses(("food", 5), ("clothes", 3),  ("food", 5), ("beverages", 3), ("beverages", 9))
    print(expenses)
    report = format_output(expenses)
    print(report)
